# sdk使用方式

## 1. 安装

```bash
pip install faird